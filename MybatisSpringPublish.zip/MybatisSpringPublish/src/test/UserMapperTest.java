package test;

import Config.mapper.UserMapper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import pojo.User;

public class UserMapperTest {
    private ApplicationContext applicationContext;

    @Before
    public  void init(){
        this.applicationContext =
                new ClassPathXmlApplicationContext("Config/ApplicationContext.xml");
    }

    @Test
    public void queryUserById() {
        UserMapper bean = applicationContext.getBean(UserMapper.class);
        User user = bean.queryUserById(26);
        System.out.println(user);
    }

}