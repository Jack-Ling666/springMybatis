package Config.mapper;

import pojo.User;

import java.util.List;

public interface UserMapper {
    User queryUserById(Integer id);
}
